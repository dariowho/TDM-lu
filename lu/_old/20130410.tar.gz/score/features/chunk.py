def c_stub(score,C_F,C_T,table):
	max_scores = []
	for cf_i in C_F:
		max_i = table.get_score(cf_i,C_T[0])
		for ct_j in C_T:
			if table.get_score(cf_i,ct_j) > max_i:
				max_i = table.get_score(cf_i,ct_j)
		max_scores.append(max_i)
	
	_r = 1
	for s in max_scores:
		#~ print(s)
		#~ print(s.features)
		#~ print(s.weights)
		#~ print(s.is_feature_set)
		_r = _r * s.get_score()
		
	score.set_feature(score.STUB_FEATURE,_r)
