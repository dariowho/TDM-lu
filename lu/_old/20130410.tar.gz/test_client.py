#!/usr/bin/python2

import LU

l = LU.Language()

# l.load()

l.import_l("language_base/stub_language.l")
# l.export_l("language_base/stub_language_E.l")


l.understand("increase the volume, please")
