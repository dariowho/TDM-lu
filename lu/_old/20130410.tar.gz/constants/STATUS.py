"""
This file defines constants to code object status information
"""

OK     = 0
EMPTY  = 1
BROKEN = 2
