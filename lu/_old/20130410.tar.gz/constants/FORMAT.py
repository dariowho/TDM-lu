"""
This file defines constants related to the Language file format, .l
"""

LINE_N_TOKENS = 3

P_LABEL    = 0
P_WEIGHT   = 1
P_SENTENCE = 2
