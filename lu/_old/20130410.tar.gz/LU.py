# -*- coding: utf-8 -*-

import sys

from array import array
from nltk import tokenize

from constants import *
from language_base import stub_language

import score.chunk
import score.word

"""
LANGUAGE UNIT - Classes and functions for handling language
===========================================================

The purpose of this package is to load a language, understand sentences of the
language, and incrementally learn the language through experience.

A language is here defined by a set of sentences, each of them is labeled with
a logical form. To understand a sentence means to associate it to its logical
form. This can happen in two ways:
 - The sentence is already existing in the memorized language
 - The sentence is considered semantically affine to a particular label.
Unrecognized sentences, once understood, can be used to enrich the system's
knowledge of the language.
"""

#
# The Language class
#

class Language:
	# Status
	_valid   = False
	_status  = STATUS.EMPTY
	
	# Training language
	sentence = []
	label    = []
	weight   = []

	#
	# Meta-methods
	#

	def __init__(self):
		self._valid  = False
		self._status = STATUS.EMPTY
		
	def validate(self):
		"""
		Check the language is consistent (should always be...)
		
		TODO: implement
		"""
		
		self._status = STATUS.OK
		return True
		
	#
	# Input/Output methods
	#
	
	def load(self,path=None):
		"""
		Load a language from a binary Language file (*.lo, a pickled Python
		class)
		
		TODO: implement (as of now it loads a stub language)
		"""
		
		if path is not None:
			raise(NotImplementedError)
		
		self.sentence = stub_language.sentence
		self.label    = stub_language.label
		self.weight   = stub_language.weight
	
	def save(self,path):
		"""
		Saves the current language into a binary Language file (*.lo, a pickled
		Python class)
		
		TODO: implement
		"""
		
		f = open(path,'r')
	
	def import_l(self,path):
		"""
		Import the language from a human-readable language file (*.l)
		"""
		
		f = open(path,'r')
		
		ln = 0
		for line in f:
			ln = ln+1
			
			# Skip empty lines
			if line == "" or not line.strip():
				continue
			
			# Skip comments
			if line[0] == "#":
				continue
			
			# Parse the line
			tokens = line.split('\t')

			try:
				self.label.append( unicode(tokens[FORMAT.P_LABEL]) )
				self.weight.append( float(tokens[FORMAT.P_WEIGHT]) )
				self.sentence.append( unicode(tokens[FORMAT.P_SENTENCE].strip()) )
			except:
				sys.stderr.write("LU.Language.import_L(): Error processing line "+unicode(ln)+". Skipping.\n")
				continue
			
		return True
		
	def export_l(self,path):
		"""
		Export the language into a human-readable language file (*.l)
		"""
		
		f = open(path,'w')
		
		f.write("# This is an automatically generated Language file\n")
		
		# Label [TAB] Weight [TAB] Sentence [NEWLINE]
		for i in range(len(self.sentence)):
			f.write(unicode(self.label[i])+u'\t'+ \
			        unicode(self.weight[i])+u'\t'+ \
			        unicode(self.sentence[i])+u'\n')
		
		f.close()
		
		return True

	#
	# Core methods
	#

	def understand(self,sentence_in):
		"""
		Assign an input sentence to one of the labels of the language, perfor-
		ming a semantic match
		"""
		
		i = 0
		for sentence_l in self.sentence:
			print(sentence_l)
			print(">> " + unicode(self._score_sentence(sentence_in,sentence_l)) )
			print()
			i = i+1

	#
	# Private methods
	#

	def _score_sentence(self,sentence_from,sentence_to):
		"""
		Scores the similarity between 'sentence_from' and 'sentence_to'.
		The higher the score, the higher the similarity.
		
		TODO: implement properly
		"""
		
		#
		# M2 testing
		#
		
		return self._score_chunk(Chunk(sentence_from,1),Chunk(sentence_to,1)).get_score()
		
		#
		# OLD CODE
		#
		r = 0
		# Loops through every possible combination of words
		# NOTE: enumerate starts from 1, because chunks count should start from 1
		for i,word_from_s in enumerate(tokenize.WordPunctTokenizer().tokenize(sentence_from),1):
			for j,word_to_s in enumerate(tokenize.WordPunctTokenizer().tokenize(sentence_to),1):
				word_from = Word(word_from_s,i)
				word_to = Word(word_to_s,j)
				# ChunkScore for two words = WordScore
				word_score = score.word.get_score(word_from,word_to)
				r = r+word_score.get_score()
				print("	"+word_from.text+unicode(i)+" - "+word_to.text+unicode(j)+" ; "+unicode(word_score.get_score()))
				for f in word_score.features:
					print("		"+str(f))
		
		return r
		
	def _score_chunk(self,chunk_from,chunk_to):
		"""
		Scores the similarity between two chunks of text.
		"""

		return score.chunk.get_score_m2(chunk_from,chunk_to)

#
# Data Structures
#

class Chunk(object):
	"""
	A Chunk is a piece of sentence containing one or more words. It is ini-
	tialised with it text content and its position in the sentence (number 
	of Chunks preceding it, plus one).
	
	Even though this is meant to be done only by Chunk methods, a Chunk can be
	initialized with a list of words. In this case no text content is expected.
	
	The text content is always set by concatenating the single words with
	spaces. NOTE: the text content may differ from the initialization string
	(eg. "One, two, three" > "One , two , three") 
	"""
	
	# The function which is used to tokenize input: it is important that chunks
	# of text are always tokenized the same way
	_tokenize = tokenize.WordPunctTokenizer().tokenize
	
	def __init__(self,text_in,position_in,_words_in=None):
		assert position_in > 0
		assert (text_in is not None) ^ (_words_in is not None)
		
		# Words list can be given or extracted from the text input string
		if _words_in is not None:
			self.words = _words_in
		else:
			self.words = [Word(x,position_in+i) for i,x in enumerate(Chunk._tokenize(text_in))]

		self.position  = position_in
		self.text  = " ".join([x.text for x in self.words])
		self.length    = len(self.words)

	def __eq__(self,other):
		if self.length == 1 and other.length == 1:
			return (self.text == other.text) and (self.position == other.position)
		
		return (self.words == other.words) and (self.position == other.position)
	
	def __ne__(self,other):
		return not self.__eq__(other)
		
	def is_word(self):
		return self.length == 1
	
	def split(self,n):
		"""
		Split the chunk in two smaller chunks, the first from the beginning to 
		the n-th word (included) and the second from the [n+1]-th word to the 
		end.
		
		Returns a list containing the two chunks, or a single chunk being self
		is the split is on the last word.
		
		Single word chunks are always returned as Word objects.
		"""
		assert n <= self.length
		assert n >= 1
		
		if n == 1:
			if n == self.length:
				assert len(self.words) == 1
				return self.words
				
			c1 = self.words[0]
		else:
			if n == self.length:
				return [self]
				
			c1 = Chunk(None,self.position,self.words[:n])
		
		c2 = Chunk(None,self.position+n,self.words[n:])
		
		return [c1,c2]


class Word(object):
	"""
	A word is a Chunk with one word.
	"""
	
	def __init__(self,text_in,position_in):
		
		self.text     = text_in
		self.position = position_in
		self.length   = 1
	
	def __eq__(self,other):
		return (self.text == other.text) and (self.position == other.position)
	
	def __ne__(self,other):
		return not self.__eq__(other)
		
	def __str__(self):
		return self.text+str(self.position)
		
	def __repr__(self):
		return self.__str__()

	def is_word(self):
		return True
	
	def split(self,n):
		assert n == 1
		
		return [self]
