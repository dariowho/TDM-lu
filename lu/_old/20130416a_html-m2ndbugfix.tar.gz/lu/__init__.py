from nltk import tokenize

#
# Data Structures
#


class Chunk(object):
	"""
	A Chunk is a piece of sentence containing one or more words. It is ini-
	tialised with it text content and its position in the sentence (number 
	of Chunks preceding it, plus one).
	
	Even though this is meant to be done only by Chunk methods, a Chunk can be
	initialized with a list of words. In this case no text content is expected.
	
	The text content is always set by concatenating the single words with
	spaces. NOTE: the text content may differ from the initialization string
	(eg. "One, two, three" > "One , two , three") 
	"""
	
	# The function which is used to tokenize input: it is important that chunks
	# of text are always tokenized the same way
	_tokenize = tokenize.WordPunctTokenizer().tokenize
	
	def __init__(self,text_in,position_in,_words_in=None):
		assert position_in > 0
		assert (text_in is not None) ^ (_words_in is not None)
		
		# Words list can be given or extracted from the text input string
		if _words_in is not None:
			self.words = _words_in
		else:
			self.words = [Word(x,position_in+i) for i,x in enumerate(Chunk._tokenize(text_in))]

		self.position  = position_in
		self.text  = " ".join([x.text for x in self.words])
		self.length    = len(self.words)

	def __eq__(self,other):
		if other is None:
			return False
		
		if self.length == 1 and other.length == 1:
			return (self.text == other.text) and (self.position == other.position)
		
		return (self.words == other.words) and (self.position == other.position)
	
	def __ne__(self,other):
		return not self.__eq__(other)
		
	def is_word(self):
		return self.length == 1
	
	def split(self,n):
		"""
		Split the chunk in two smaller chunks, the first from the beginning to 
		the n-th word (included) and the second from the [n+1]-th word to the 
		end.
		
		Returns a list containing the two chunks, or a single chunk being self
		is the split is on the last word.
		
		Single word chunks are always returned as Word objects.
		"""
		assert n <= self.length
		assert n >= 1
		
		if n == 1:
			if n == self.length:
				assert len(self.words) == 1
				return self.words
				
			c1 = self.words[0]
		else:
			if n == self.length:
				return [self]
				
			c1 = Chunk(None,self.position,self.words[:n])
		
		c2 = Chunk(None,self.position+n,self.words[n:])
		
		return ChunkedChunk([c1,c2])
	
	def penn_string(self):
		return "c'"+self.text+"'"
		
	def __str__(self):
		return self.penn_string()
		
	def __repr__(self):
		return self.__str__()

class ChunkedChunk(list):
	"""
	How much wood would a woodchuck chunk if a woodchuk could chunk wood?
	
	TODO: test this data structure
	"""
	
	def is_word(self):
		return (len(self)==1) and (self[0].is_word())
	
	def penn_string(self):
		"""
		Return the chunk as a string in the Penn Treebank format
		"""
		
		#~ return "(CC "+" ".join(x.penn_string() for x in self)+")"
		return "(CC "+" ".join(str(x) for x in self)+")"
		
	def __str__(self):
		return self.penn_string()
		
	def __repr__(self):
		return self.__str__()
		

class Word(object):
	"""
	A word is a Chunk with one word.
	"""
	
	def __init__(self,text_in,position_in):
		
		self.text     = text_in
		self.position = position_in
		self.length   = 1
	
	def __eq__(self,other):
		if other is None:
			return False
		
		return (self.text == other.text) and (self.position == other.position)
	
	def __ne__(self,other):
		return not self.__eq__(other)
		
	def __str__(self):
		return self.text+str(self.position)
		
	def __repr__(self):
		return self.__str__()

	def is_word(self):
		return True
	
	def split(self,n):
		assert n == 1
		
		return [self]
		
	def penn_string(self):
		return "w'"+self.text+"'"
