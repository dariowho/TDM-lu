#!/usr/bin/python2

import LU

l = LU.Language()

# l.load()

# M2 DEBUG

l.import_l("language_base/toy_m2.l")

#~ l.understand("one")

print("<!DOCTYPE html>\
<html>\
<head>\
  <meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">\
  <title>LU Output debugger</title>\
  \
  <script type='text/javascript' src='jquery-1.9.1.min.js'></script>\
  \
  <style type='text/css'>\
    li ul {\
    display: none;\
}\
\
	#content {\
		%border:1px solid black;\
	}\
	\
	.sd {\
		width:40%;\
		border-left:1px solid black;\
		\
		position:absolute;\
		right:0;\
		top:0;\
		\
		height:100%;\
		\
		background:white;\
	}\
	\
	.sd p {\
		margin:1em;\
	}\
	\
	#left {\
		width:60%;\
		%border:1px solid black;\
	}\
	\
	#left h1 {\
		font-size:1.5em;\
		background:lightgray;\
		margin:0;\
		padding:.5em;\
	}\
	\
	\
\
  </style>\
  \
\
\
<script type='text/javascript'>\
function showSD(id) {\
  $('.sd').hide();\
  $('#'+id).show(); \
}\
\
//<![CDATA[ \
$(window).load(function(){\
$(\"#content li > a\").click(function() {\
    var li = $(this).closest('li');\
    li.find(' > ul').slideToggle('fast');\
});\
});\
\
//]]>  \
\
</script>\
\
\
</head>\
<body>\
	<p><small>LU dev-20130413</small></p>\
	<p onmouseover=\"showSD('sd-default');\">Understanding sentence: <em>Increase the vulume</em></p>\
	\
	\
  <div id=\"content\">\
	<div id=\"left\">\
	<h1>Meaning: 1</h1>\
	<ul>")


l.understand("one two three")

print("	</ul> \
</div>\
<script>\
showSD('sd-default');\
</script>\
</body>\
\
\
</html>")

# BASE

#~ l.import_l("language_base/stub_language.l")
# l.export_l("language_base/stub_language_E.l")

#~ l.understand("increase the volume, please")
