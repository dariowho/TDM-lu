from lu import ChunkedChunk

def c_stub(score,C_F,C_T,table):
	max_scores = []
	for cf_i in C_F:
		max_i = table.get_score(cf_i,C_T[0])
		for ct_j in C_T:
			if table.get_score(cf_i,ct_j).get_score() > max_i.get_score():
				max_i = table.get_score(cf_i,ct_j)
		max_scores.append(max_i)
		
		
	# TEMP CODE to save the chunking hierarchy
	s_from = ChunkedChunk()
	for cf_i in C_F:
		max_i = table.get_score(cf_i,C_T[0])
		for ct_j in C_T:
			if table.get_score(cf_i,ct_j) > max_i:
				max_i = table.get_score(cf_i,ct_j)
		s_from.append(max_i.s_from)
	score.s_from = s_from
	
	s_to = ChunkedChunk()
	for ct_j in C_T:
		max_j = table.get_score(C_F[0],ct_j)
		for cf_i in C_F:
			if table.get_score(cf_i,ct_j) > max_j:
				max_j = table.get_score(cf_i,ct_j)
		s_to.append(max_j.s_to)
	score.s_to = s_to
	
	_r = 1
	for s in max_scores:
		#~ print(s)
		#~ print(s.features)
		#~ print(s.weights)
		#~ print(s.is_feature_set)
		_r = _r * s.get_score()
		
	score.set_feature(score.STUB_FEATURE,_r)
