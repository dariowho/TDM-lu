# -*- coding: utf-8 -*-

from array import array

from . import Score,word
from lu import ChunkedChunk,Chunk
import features.chunk

# DEBUG
#~ d_recursion_level = 0

# HTML RENDER (tmp)
_html_prefix = 0

class ChunkScore(Score):
	"""
	A ChunkScore holds the score of the comparison of two Chunks.
	"""
	
	# Total number of features
	N_FEATURES = 1
	
	# Constant feature names (must define N_FEATURES names)
	STUB_FEATURE = 0

	def __init__(self):
		super(ChunkScore,self).__init__()

		self.features = array('f',[0]*ChunkScore.N_FEATURES)
		self.weights  = array('f',[1.0/ChunkScore.N_FEATURES]*ChunkScore.N_FEATURES)
		self.is_feature_set = array('b',[False]*ChunkScore.N_FEATURES)

		self.s_from = Chunk("__EMPTY_CHUNK_FROM__",1)
		self.s_to   = Chunk("__EMPTY_CHUNK_TO__",1)

# POSTPONED: just basic information is in ChunkScore
#~ class DebugChunkScore(ChunkScore):
	#~ """
	#~ A DebugChunkScore is a ChunkScore with additional information to inspect the
	#~ detail of the Score (recursive backreferences to all its components)
	#~ """
#~ 
	#~ def __init__(self,):
		#~ super(DebugChunkScore,self).__init__()
		#~ 
		#~ self.s_from = Chunk("__EMPTY_CHUNK_FROM__",1)
		#~ self.s_to   = Chunk("__EMPTY_CHUNK_TO__",1)


# Hooks (must match the order of the names in WordScore)
_f = [ features.chunk.c_stub ]

class M2Table(object):
	"""
	A M2Table object holds a partially precomputed M2-score relation between 
	two chunks
	"""
	
	def __init__(self,chunk_from,chunk_to):
		
		# DEBUG
		#~ print("T_dim: "+str(chunk_from.length)+"x"+str(chunk_from.length)+"x"+str(chunk_to.length)+"x"+str(chunk_to.length) )
		
		# TODO: change this with an optimized matrix
		self.table = [[[[None for x in xrange(chunk_to.length)] for x in xrange(chunk_to.length)] for x in xrange(chunk_from.length)] for x in xrange(chunk_from.length)]
		self.chunk_from = chunk_from
		self.chunk_to   = chunk_to
	
	def set_score(self,score,chunk_from,chunk_to):
		assert self.table[chunk_from.position-1][chunk_from.position+chunk_from.length-2][chunk_to.position-1][chunk_to.position+chunk_to.length-2] is None
		
		self.table[chunk_from.position-1][chunk_from.position+chunk_from.length-2][chunk_to.position-1][chunk_to.position+chunk_to.length-2] = score

	def get_score(self,chunk_from,chunk_to):
		assert self.table[chunk_from.position-1][chunk_from.position+chunk_from.length-2][chunk_to.position-1][chunk_to.position+chunk_to.length-2] is not None
		
		return self.table[chunk_from.position-1][chunk_from.position+chunk_from.length-2][chunk_to.position-1][chunk_to.position+chunk_to.length-2]
	
	def is_score_set(self,chunk_from,chunk_to):
		# DEBUG
		#~ global d_recursion_level
		#~ print("\t"*d_recursion_level+"T_isset: from: "+str(chunk_from.position)+","+str(chunk_from.length))
		#~ print("\t"*d_recursion_level+"T_isset: to  : "+str(chunk_to.position)+","+str(chunk_to.length))
		
		return self.table[chunk_from.position-1][chunk_from.position+chunk_from.length-2][chunk_to.position-1][chunk_to.position+chunk_to.length-2] is not None

	def render_txt(self,from_a=1,from_b=None,indent=0):
		if from_b == None:
			from_b = self.chunk_from.length
			
		assert from_a > 0
		assert from_a <= self.chunk_from.length
		assert from_b > 0
		assert from_b <= self.chunk_from.length
		assert from_a <= from_b
		
		if from_a == from_b:
			print("\t"*indent+"-"+str(from_a)+"-,-"+str(from_b)+"-")
			return
		
		for i in range(from_a,from_b):
			print("\t"*indent+"("+str(from_a)+","+str(i)+","+str(from_b)+")")
			self.render_txt(from_a,i,indent+1)
			self.render_txt(i+1,from_b,indent+1)

	def render_html(self,chunk=None,prefix="",indent=0):
		if chunk == None:
			chunk = self.chunk_from
			self._render_html_sd_all(chunk,prefix,indent)

		chunk_start = chunk.position
		chunk_end   = chunk.position+chunk.length-1
		sd_id       = "sd-"+prefix+str(chunk_start)+"-"+str(chunk_end)
			
		print("\t"*indent+"<li><a href='#' onmouseover='showSD(\""+sd_id+"\")'>"+str(chunk)+" - <span class='light'>"+str(self.chunk_to)+"</span></a>")
		if not chunk.is_word():
			print("\t"*indent+"<ul>")
			for i in range(1,chunk.length):
				cc = chunk.split(i)
				print("\t"*indent+"<li><a href='#'>"+" | ".join([str(x) for x in cc])+" - <span class='light'>"+str(self.chunk_to)+"</span></a>")
				print("\t"*indent+"<ul>")
				for c in cc:
					self.render_html(c,prefix,indent+1)
				print("\t"*indent+"</ul>")
				print("\t"*indent+"</li>")
			print("\t"*indent+"</ul>")
		print("\t"*indent+"</li>")
		print("")

	def _render_html_sd_all(self,chunk,prefix,indent,donelist=[]):
		chunk_start = chunk.position
		chunk_end   = chunk.position+chunk.length-1
		sd_id = "sd-"+prefix+str(chunk_start)+"-"+str(chunk_end)
		if sd_id not in donelist:
			self._render_html_sd(chunk,sd_id,indent)

		if not chunk.is_word():
			for i in range(1,chunk.length):
				cc = chunk.split(i)
				for c in cc:
					self._render_html_sd_all(c,prefix,indent,donelist)


	def _render_html_sd(self,chunk,sd_id,indent):
		print("\t"*indent+"<div class='sd' id='"+sd_id+"'>")
		print("\t"*indent+"All the possible scores of <em>"+chunk.text+"</em>.")
		print("\t"*indent+"<ul>")
		self._render_html_sd_inner(chunk,None,indent)
		print("\t"*indent+"</ul>")
		print("\t"*indent+"</div>")
		
	def _render_html_sd_inner(self,chunk_from,chunk_to=None,indent=0):
		if chunk_to is None:
			chunk_to = self.chunk_to

		print("\t"*indent+"<li>")
		print("\t"*indent+"<a href='#'><span class='light'>"+str(chunk_from)+"</span> - "+str(chunk_to)+"</a>")
		score = self.get_score(chunk_from,chunk_to)
		print("<ul class='score'>")
		print(score.s_from.penn_string()+"<br/>")
		print(score.s_to.penn_string())
		score.render_html()
		print("<li class='total'>"+str(score.get_score())+"</li>")
		print("</ul>")
		if not chunk_to.is_word():
			print("\t"*indent+"<ul>")
			for i in range(1,chunk_to.length):
				cc = chunk_to.split(i)
				print("\t"*indent+"<li><a href='#'><span class='light'>"+str(chunk_from)+"</span> - "+" | ".join([str(x) for x in cc])+"</a>")
				print("\t"*indent+"<ul>")
				for c in cc:
					self._render_html_sd_inner(chunk_from,c,indent+1)
				print("\t"*indent+"</ul>")
				print("\t"*indent+"</li>")
			print("\t"*indent+"</ul>")
		print("\t"*indent+"</li>")
	
def get_score_m2(chunk_from,chunk_to):
	"""
	Runs the actual score computing function, initialized with an empty M2Table
	"""
	# Original, withoud debug inserts
	#~ return _get_score_m2(chunk_from,chunk_to,M2Table(chunk_from,chunk_to))
	
	table = M2Table(chunk_from,chunk_to)
	r = _get_score_m2(chunk_from,chunk_to,table)
	
	# Stuff for HTML generation, all of it should be moved to a View class
	# Note that html output needs the final score to be pushed in the table
	table.set_score(r,chunk_from,chunk_to)
	global _html_prefix
	prefix = str(_html_prefix)+"-"
	table.render_html(None,prefix)
	_html_prefix = _html_prefix+1
	
	return r

def _get_score_m2(chunk_from,chunk_to,table):
	"""
	This function scores the similarity between two chunks using the M2-score
	algorithm.
	
	This algorithm makes use of Dynamic Programming to reduce the computation 
	time, still comparing every possible alignment of every possible 
	sub-chunking of the two input chunks.
	
	'chunk_from' and 'chunk_to' are two Chunk object. 'table' is a M2Table
	object, representing the partially precomputed M2-score relation. This 
	table, initially empty, gets filled as the algorithm runs; in the end it
	will contain all the partial scores (one ChunkScore object for each possible
	combination of sub-chunking of chunk_from and chunk_to).
	"""
	
	
	# DEBUG
	#~ global d_recursion_level
	#~ print("\t"*d_recursion_level+"M2: '"+chunk_from.text+"','"+chunk_to.text+"'")
	#~ print("\t"*d_recursion_level+"    '"+str(chunk_from.length)+"','"+str(chunk_to.length)+"'")
	#~ print("\t"*d_recursion_level+"    '"+str(chunk_from.position)+"','"+str(chunk_to.position)+"'")
	#~ d_recursion_level = d_recursion_level+1
	
	if chunk_from.is_word() and chunk_to.is_word():
		# DEBUG
		#~ print("word score returned")
		#~ d_recursion_level = d_recursion_level-1
		
		# TODO: The two ChunkedChunks that are being compared are saved in
		#       the Score. Coding style apart, this shouldn't affect the
		#       performance too much; anyway, it would be better to check.
		#       See also the feature hook.
		r = word.get_score(chunk_from,chunk_to)
		r.s_from = chunk_from
		r.s_to   = chunk_to
		return word.get_score(chunk_from,chunk_to)
	
	# TODO: precompute the size
	candidate_scores = []
	
	# For every 2-split of 'chunk_from'
	for i in range(1,chunk_from.length+1):
		C_F = chunk_from.split(i)
		
		# For every 2-split of 'chunk_to'
		for j in range(1,chunk_to.length+1):
			
			# Prevent infinite loops
			# DEBUG
			#~ print ("\t"*d_recursion_level+"i:"+str(i)+","+str(chunk_from.length))
			#~ print ("\t"*d_recursion_level+"j:"+str(j)+","+str(chunk_to.length))
			if (i == chunk_from.length) and (j == chunk_to.length) and \
			   (i != 1 or j != 1):
				# DEBUG
				#~ print("Infinite loop prevented")
				break
			
			C_T = chunk_to.split(j)
			
			# Compute the scores of every possible alignment, if not done yet
			# NOTE: C_F and C_T are list of chunks or words; typically they
			#       contain 2 chunks (the 2-split of chunk_*), but it can also 
			#       be one (when the entire chunk_* is compared with the 
			#       sub-chunks of the other) 
			for cf_i in C_F:
				for ct_j in C_T:
					if not table.is_score_set(cf_i,ct_j):
						# DEBUG
						#~ print("score("+str(cf_i.text)+","+str(ct_i.text)+")")
						table.set_score(_get_score_m2(cf_i,ct_j,table),cf_i,ct_j)
					# DEBUG
					#~ else:
						#~ print("HIT! "+cf_i.text+","+ct_i.text)
			
			#~ print("-------------------------------------------")
			
			# Compute the score for chunk_from and chunk_to, under this 
			# particular sub-chunking. This score is added to the list of
			# candidate scores; the best score (ie. the best sub-chunking) will
			# be selected in the end
			# NOTE: it is up to the score to handle the alignment of the 
			#       sub-chunks in the two sentences
			score = ChunkScore()
			for fn,f in enumerate(_f):
				if not score.is_feature_set[fn]:
					f(score,C_F,C_T,table)
			candidate_scores.append(score)
			
			# DEBUG
			#~ print score
	
	# DEBUG
	#~ print(candidate_scores)
	
	# Return the best score
	max_score = candidate_scores[0]
	for s in candidate_scores:
		if s.get_score() > max_score.get_score():
			max_score = s
			
	#DEBUG
	#~ d_recursion_level = d_recursion_level-1
	
	return max_score

def _get_chunk_score_m2(C_F,C_T,table):
	score = ChunkScore()
	for fn,f in enumerate(_f):
		if not score.is_feature_set[fn]:
			f(score,C_F,C_T,table)
	return score
