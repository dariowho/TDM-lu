sentence = ["increase the volume", "crank the volume", "decrease the volume", "stop the music", "skip this track"]
label    = [1,1,2,3,4]
weight   = [1,1,1,1,1]
