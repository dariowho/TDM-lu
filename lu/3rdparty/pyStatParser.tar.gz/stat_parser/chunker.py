"""
Chunks a sentence into its syntactic constituents, based on the parse tree
returned by Parser.parse().

NOTE: This module requires the parse tree to be given as a nltk.Tree data
      structure
"""

from stat_parser import Parser

# Requires NLTK
from nltk import Tree

class Chunker():
	
	def __init__(self):
		self.parser = Parser()
	
	def chunk(self,s):
		"""
		Returns a list of lists containing the constituents of the input
		sentence s.
		
		Example
			IN:  "I saw the cat with the telescope"
			OUT: ['I', ['saw', ['the', 'cat'], ['with', ['the', 'telescope']]]]
		"""
		
		tree = self.parser.parse(s)
		
		return self._get_chunks(tree)

	def get_phrases(self,chunked_s):
		"""
		Returns the full list of syntactic chunks contained in the input
		chunked sentence chunked_s. chunked_s is meant to be the output of 
		self.chunk().
		
		Example:
			IN:  ['I', ['saw', ['the', 'cat'], ['with', ['the', 'telescope']]]]
			OUT: set([u'telescope', u'the cat', u'I', u'saw', u'cat', 
			          u'the telescope', u'saw the cat with the telescope',
			          u'with the telescope', u'the', u'with'])
		"""
		r = set()
		self._merge(chunked_s,r)
		
		return r
	
	
	"""
	Private methods
	"""
	
	def _get_chunks(self,t):
		if (isinstance(t,basestring)):
			return unicode(t)
			
		if (len(t)==1):
			return self._get_chunks(t[0])

		r = []
		for c in t:
			r.append( self._get_chunks(c) )
			
		return r

	def _merge(self,l,phrases = set()):
		if (isinstance(l,basestring)):
			return l
		
		r = u""
		for c in l:
			m = self._merge(c,phrases)
			r = r+" "+m
			phrases.add(m)
		
		return r.strip()
